package com.example.a381a5p2;

public interface SketchListener {
    void modelChanged();
}
