package com.example.a381assignment5;

public interface SketchListener {
    void modelChanged();
}
