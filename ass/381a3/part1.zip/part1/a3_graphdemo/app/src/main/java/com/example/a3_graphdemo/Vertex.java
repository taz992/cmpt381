package com.example.a3_graphdemo;

public class Vertex extends MainActivity {
}
