package com.example.a3_graphdemo;

public class GraphModel extends MainActivity {
}
