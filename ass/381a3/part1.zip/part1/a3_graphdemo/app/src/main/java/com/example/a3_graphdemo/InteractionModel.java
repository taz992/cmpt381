package com.example.a3_graphdemo;

public class InteractionModel extends MainActivity {
}
