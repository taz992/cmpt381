package sample;
import java.util.ArrayList;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.util.Pair;
import java.util.List;



public class Controller {
    /*
    Blob model;
    BlobView view;
    InteractionModel interModel;
    ArrayList<Groupable> selectedGroups;
    ArrayList<Groupable> clipboard;
    boolean controlDown;
    boolean CDown;
    boolean VDown;
    boolean XDown;

    double rectSelectX1, rectSelectY1, rectSelectX2, rectSelectY2;
    Groupable groupToBeMoved = null;

    int state = 0;
    final int STATE_READY = 0;
    final int STATE_RECTSELECT = 1;
    final int STATE_SELECTED = 2;
    final int STATE_READY_TO_CREATE = 3;
    final int STATE_MOVING = 4;

    float lastX, lastY;
    float initialX, initialY;

    public void copy(){
        //control-c
    }

    public void cut(){
        //control-x
    }

    public void paste(){
        //control-p
    }
    */

}
