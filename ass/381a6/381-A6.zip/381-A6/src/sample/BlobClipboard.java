package sample;

import java.util.ArrayList;


public class BlobClipboard {
    ArrayList<Groupable> items;
}
