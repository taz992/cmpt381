package sample;

public class MoveCommand {

}
