package sample;

public interface BlobModelListener {
    void modelChanged();
}
