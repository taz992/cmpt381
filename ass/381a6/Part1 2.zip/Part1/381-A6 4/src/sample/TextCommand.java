package sample;

public interface TextCommand {
    void doIt();
    void undo();
}
