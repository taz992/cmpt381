package sample;

public interface BlobModelListener {
    public void modelChanged();
}
